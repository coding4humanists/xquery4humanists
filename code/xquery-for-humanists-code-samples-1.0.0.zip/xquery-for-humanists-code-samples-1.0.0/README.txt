XQuery for Humanists - Code Samples

Version: 1.0.0
Released: March 22, 2020

This archive contains code samples adapted from Clifford B. Anderson and Joseph C. Wicentowski, _XQuery for Humanists_ (College Station: Texas A&M University Press, 2020), to facilitate your learning of the material.

In the book, many code samples were presented in partial form in the course of discussion. The corresponding versions of the code samples here have been expanded, as needed, to ensure they can all run as standalone queries. When a query cannot be run as a standalone query, it is shown with a "txt" file extension file rather than the "xq" file extension.

For the latest version of the code samples, please visit https://xquery.forhumanists.org.
